clc;
clear all;

c = 6245706;
n = 9353881;
m = factor(n);

mod_square_roots(c, m(1), m(2))