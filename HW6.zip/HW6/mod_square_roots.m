function [ m ] = mod_square_roots( c, p, q )

n = [p q];

c_1(1) = fast_exponentiation(p, c, (p+1)/4);
c_1(2) = fast_exponentiation(p, -c, (p+1)/4);
c_2(1) = fast_exponentiation(q, c, (q+1)/4);
c_2(2) = fast_exponentiation(q, -c, (q+1)/4);

m(1) = mod(crt(n, [c_1(1), c_2(1)]), p*q);
m(2) = mod(crt(n, [c_1(2), c_2(1)]), p*q);
m(3) = mod(crt(n, [c_1(1), c_2(2)]), p*q);
m(4) = mod(crt(n, [c_1(2), c_2(2)]), p*q);

end

